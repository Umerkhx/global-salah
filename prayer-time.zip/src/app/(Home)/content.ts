export interface Content {
  text?: string;
  source?: string;
  arabic?: string;
  english?: string;
  refrence?: string;
  translation?: string;
}
