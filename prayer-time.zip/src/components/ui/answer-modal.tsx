"use client";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { useTranslation } from "@/hooks/useTranslation";
import { urlSplitter } from "@/lib";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";

interface AnswerModalProps {
  questionId: string;
  onAnswerAdded: () => void;
  buttonVariant?: "default" | "outline" | "ghost";
  buttonSize?: "default" | "sm" | "lg" | "icon";
  buttonClassName?: string;
  isVerified: boolean;
}

export function AnswerModal({
  questionId,
  isVerified,
  onAnswerAdded,
  buttonVariant = "outline",
  buttonSize = "sm",
  buttonClassName = "",
}: AnswerModalProps) {
  const router = useRouter();
  const pathname = usePathname();
  const lang = urlSplitter(pathname);
  const { t } = useTranslation("forum");
  const [answer, setAnswer] = useState("");
  const [userId, setUserId] = useState<any>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const storedUserData = localStorage.getItem("userData");
    if (storedUserData) {
      const parsedUserData = JSON.parse(storedUserData);
      setUserId(parsedUserData.id);
    }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!answer.trim()) return;

    setIsSubmitting(true);
    try {
      const answerDetail = { user_id: userId, question_id: questionId, answer };

      const response = await fetch("/api/answers/add-answer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(answerDetail),
      });

      if (response.ok) {
        setAnswer("");
        setOpen(false);
        onAnswerAdded();
        router.push(`/${lang}/answer-submitted`);
      } else {
        console.error("Failed to add answer:", await response.json());
      }
    } catch (error) {
      console.error("Error adding answer:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant={buttonVariant}
          size={buttonSize}
          className={buttonClassName}
        >
          {t("forum.answerbuttontext")}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px] z-[1000]">
        <DialogHeader>
          <DialogTitle>{t("forum.postanswers")}</DialogTitle>
          <DialogDescription>{t("forum.postanswersdesc")}</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <Textarea
            placeholder={t("forum.answerplaceholder")}
            className="min-h-[200px]"
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
          />
        </div>
        <DialogFooter />
        <div className="flex justify-end items-end gap-3">
          <Button
            variant="outline"
            onClick={() => setOpen(false)}
            disabled={isSubmitting}
          >
            {t("forum.cancel")}
          </Button>

          <Button
            className="text-white bg-emerald-600 hover:bg-emerald-800"
            onClick={handleSubmit}
            disabled={isSubmitting}
          >
            {isSubmitting ? `${t("forum.posting")}` : `${t("forum.postanswer")}`}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
