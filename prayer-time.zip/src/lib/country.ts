export interface Country {
    name: string
    code: string
    timezone: string
    offset: string
  }
  